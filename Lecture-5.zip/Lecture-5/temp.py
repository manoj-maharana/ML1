A = ["anand", "Abc"]
B = ["mishra", "xyz"]

for a in zip(A,B):
	print(a)
	
